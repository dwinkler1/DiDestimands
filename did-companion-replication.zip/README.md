# DiD Estimand Companion — Replication Package

Companion code for the interactive applet at **https://liaukonyte.dyson.cornell.edu/did/**
(bare version: https://liaukonyte.dyson.cornell.edu/did_estimands/).

## How it works

The applet is the data generator. The **"Panel (CSV)"** buttons on its
Replication tab export the simulated panel for the current slider settings as
`did_lab_panel.csv` (columns `unit, period, pair, treat, post, D, y`; one
button uses Tab 1's matched no-growth design, the other adds Tab 2's baseline
gap *b* and common growth *g*). Each script below reads that file, estimates
the four specifications, and prints estimates with 95% confidence intervals.
A reference panel for the default settings (seed 4) is bundled, so every
script runs out of the box and can be checked against the reference values in
its header before you swap in your own export.

## Files

| File | Language | Estimation toolkit |
|---|---|---|
| `did_lab_replication.py` | Python ≥3.9 | `pyfixest` (`pip install numpy pandas scipy pyfixest`) |
| `did_lab_replication.R`  | R ≥4.0      | `fixest` (`install.packages("fixest")`) |
| `did_lab_replication.jl` | Julia ≥1.6  | `DataFrames`, `FixedEffectModels`, `GLFixedEffectModels`, `FixedEffects`, `Distributions`, `DelimitedFiles` |
| `did_lab_panel.csv`      | —           | reference panel (default settings, seed 4) |

## What each script estimates

Four specifications, each with unit and period fixed effects and a single
Treat×Post regressor:

1. **Levels OLS**, reported as a percent of the counterfactual mean
   (treated pre-period mean × control post/pre ratio); its CI uses the delta
   method, because the scale is estimated and strongly negatively correlated
   with the coefficient (a fixed-scale CI would be ~2.5× too wide)
2. **log(1+Y) OLS**
3. **Weighted log(1+Y) OLS**, weights = unit's pre-period mean outcome
   (zero-weight units dropped — numerically identical)
4. **PPML** (Poisson pseudo-ML, log link), reported as exp(β)−1

All standard errors are CRV1, clustered at the matched-pair level, with
t critical values on (pairs−1) degrees of freedom (1.959963985 + 2.3685/(G−1)).
Two-way (unit × pair) clustering — the paper's convention — is algebraically
identical: units are nested in pairs, so the CGM unit and intersection
components cancel exactly (verified to machine precision).

## Verification (bundled panel: defaults, seed 4)

```
n = 32,000   sum(y) = 23,551,023
levels  -0.03861113   [-4.4695%, -3.2527%]   (delta method)
log1y   +0.00760246   [-0.3962%, +1.9167%]
wlog    -0.03704146   [-4.3714%, -3.0369%]
ppml    -0.03859994   [-4.4669%, -3.2492%]
```

- The applet's CSV export at the default sliders is **byte-identical** to the
  bundled panel (verified), so "download → run" reproduces these numbers.
- **Python, R, and Julia — all certified by execution**: run on the bundled
  panel, the three print **digit-for-digit identical** results (levels, log1y,
  wlog, ppml, and every CI end), confirmed both in-browser (R via webR) and on a
  local machine (Python with pyfixest, R with fixest, Julia with
  FixedEffectModels/GLFixedEffectModels). PPML drops the same 60 separated
  (all-zero-unit) observations in all three.
- All three scripts use the exact t quantile at 0.975 with (pairs-1) degrees
  of freedom via each language's own quantile function (`scipy.stats.t.ppf`,
  `qt`, `Distributions.TDist`).
- If you match WITH replacement (controls reused across pairs, as in the
  paper), units no longer nest in pairs: cluster two-way by unit and pair
  (each script's comments show the syntax).
- Each script also prints a **standard regression table** (`pf.etable(type="md")`,
  `etable`, `regtable`) with the raw coefficients, for the familiar view — there
  levels is in outcome units and PPML is the log coefficient, so those columns
  differ from the scaled %/CI reported above.
- log/wlog/ppml interval ends can differ in the 3rd decimal across packages
  (small-sample SE conventions); point estimates and the delta-method levels
  CI match exactly.

## Notes

- True estimand values (typical-unit %, population-total %) are properties of
  the data-generating process and are not recoverable from the CSV; read them
  off the applet's Tab 1 cards (defaults: −0.5% and −3.8%).
- These scripts are synchronized with the applet build of **2026-06-07**.
